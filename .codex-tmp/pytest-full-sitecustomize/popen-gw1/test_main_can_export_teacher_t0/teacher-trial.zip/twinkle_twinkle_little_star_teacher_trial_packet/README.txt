UkePack 老師試用包 / Teacher Trial Packet
=======================================

目標：把老師試用前的材料一次備齊，減少來回問答。
Goal: keep the 15-minute teacher trial handoff in one ZIP.

試用網址 / Trial URL: https://trial.example/new
範例曲譜 / Suggested score: samples/twinkle_twinkle_little_star.musicxml
PDF 範例 / Generated PDF: output/cli-demo.pdf
難度等級 / Arrangement level: 1

先開哪幾個檔案 / Open these first:
1. README.txt：看這份 15 分鐘流程與網址提醒
2. docs/teacher_guide.md：老師實際操作的 5 步
3. docs/teacher/checklist.md：核對 K7 五份 onboarding 材料都在
4. docs/teacher_trial_sop.md：主持人觀察腳本、邀請信、追蹤模板
5. feedback.md：5 題回饋表 + 主持人觀察欄位
6. docs/teacher/templates/*.txt：可直接貼出去的邀請 / 排程 / 提醒 / 追蹤模板
7. docs/deployment_guide.md：若需公開 URL，照此文件部署 Render.com/Fly.io/Railway（5 分鐘）

15 分鐘流程 / Suggested flow:
1. 打開試用網址，建立專案。
2. 匯入 samples/ 內附的 MusicXML。
3. 確認授權，輸出第一份 PDF。
4. 若要示範老師審稿，照 docs/teacher_guide.md 第 8 節操作。
5. 結束前填 feedback.md，主持人同步補觀察紀錄。

✅ 這個 Trial URL 看起來可外寄；正式寄出前仍建議先自己點一次確認可連線。

Tip: send this ZIP right after the session is scheduled.
小提醒：排程一敲定就寄出這包，老師比較不會在試用前找不到檔案。
